# Book store managment system

Acest proiect reprezintă o aplicație orientată pe obiect care gestionează activitatea unui magazin de cărți. Sistemul permite administrarea informațiilor despre cărți (titlu, autor, categorie, stoc, preț) și a operațiunilor specifice unui bookstore, precum căutarea cărților, actualizarea stocurilor și procesarea vânzărilor.
